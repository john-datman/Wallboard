exports.twilio = {
  accountSid: 'ACxxxxxx',
  authToken: 'your auth token',
  workspace: 'WSxxxxxx'
};

exports.taskQueues = [
  'WQxxxxx',
  'WQxxxxx',
  'WQxxxxx'  
];
